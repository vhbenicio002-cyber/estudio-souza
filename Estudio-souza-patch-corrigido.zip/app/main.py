from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from contextlib import asynccontextmanager
import logging
from pathlib import Path

from app.config import settings
from app.database import init_db, engine, Base
from app.routes import auth, clientes, servicos, agendamentos, fidelidade, configuracao, admin, publico, produtos
from app.services.notificacao import notificacao_service
from app.services.auth import AuthService
from app.models.servico import Servico
from app.models.produto import Produto
from app.models.configuracao import ConfiguracaoBarbearia
from app.database import SessionLocal

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent

# Paths absolutos evitam falhas quando o servidor é iniciado fora da pasta do projeto.
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Não iniciar uma instalação de produção com credenciais conhecidas ou chave padrão.
    if not settings.DEBUG and (
        settings.SECRET_KEY == "change-this-secret-key-before-production"
        or "mude_em_producao" in settings.SECRET_KEY
        or len(settings.SECRET_KEY) < 32
        or settings.ADMIN_PASSWORD == "admin123"
        or len(settings.ADMIN_PASSWORD) < 12
    ):
        raise RuntimeError(
            "Configure SECRET_KEY (mínimo 32 caracteres) e ADMIN_PASSWORD fortes no .env antes de iniciar em produção."
        )
    # Startup
    logger.info("Iniciando aplicação...")
    init_db()
    # Migração aditiva e segura: acrescenta apenas a coluna de resgate em serviços.
    from sqlalchemy import inspect, text
    inspector = inspect(engine)
    if "servicos" in inspector.get_table_names():
        colunas = {c["name"] for c in inspector.get_columns("servicos")}
        if "pontos_resgate" not in colunas:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE servicos ADD COLUMN pontos_resgate INTEGER NOT NULL DEFAULT 0"))

    # Impede crédito duplicado para o mesmo agendamento também sob requisições simultâneas.
    if "transacoes_fidelidade" in inspector.get_table_names():
        with engine.begin() as conn:
            duplicados = conn.execute(text(
                "SELECT agendamento_id FROM transacoes_fidelidade "
                "WHERE agendamento_id IS NOT NULL "
                "GROUP BY agendamento_id HAVING COUNT(*) > 1 LIMIT 1"
            )).first()
            if not duplicados:
                conn.execute(text(
                    "CREATE UNIQUE INDEX IF NOT EXISTS uq_transacao_fidelidade_agendamento "
                    "ON transacoes_fidelidade (agendamento_id) WHERE agendamento_id IS NOT NULL"
                ))
            else:
                logger.warning("Há transações históricas duplicadas por agendamento; índice de proteção não foi criado.")

    # Criar usuário admin padrão
    db = SessionLocal()
    try:
        auth_service = AuthService(db)
        auth_service.create_admin_user()

        # Migração do antigo catálogo de barbearia para serviços de beleza.
        # Serviços confirmados na tabela enviada pela responsável. Durações são
        # estimativas iniciais e podem ser ajustadas no painel administrativo.
        catalogo = [
            ("Design simples", "Design de sobrancelhas.", 15.00, 30, "Sobrancelhas", 1, True),
            ("Design com henna", "Design de sobrancelhas com aplicação de henna.", 25.00, 45, "Sobrancelhas", 2, True),
            ("Cílios tufinho", "Aplicação de cílios no estilo tufinho.", 25.00, 45, "Cílios", 3, True),
            ("Remoção", "Remoção de extensão/aplicação de cílios.", 10.00, 20, "Cílios", 4, True),
            ("Manicure", "Cuidados e embelezamento das unhas das mãos. Cadastre o preço antes de ativar.", 0, 60, "Manicure", 5, False),
            ("Pedicure", "Cuidados e embelezamento das unhas dos pés. Cadastre o preço antes de ativar.", 0, 60, "Pedicure", 6, False),
        ]
        servicos_antigos = {"Corte de Cabelo", "Barba", "Corte + Barba", "Hidratação", "Sobrancelha"}
        for servico_antigo in db.query(Servico).filter(Servico.nome.in_(servicos_antigos)).all():
            servico_antigo.ativo = False
        for nome, descricao, preco, duracao, categoria, ordem, ativo in catalogo:
            existe = db.query(Servico).filter(Servico.nome == nome, Servico.categoria == categoria).first()
            if not existe:
                db.add(Servico(nome=nome, descricao=descricao, preco=preco, duracao_minutos=duracao,
                               categoria=categoria, ativo=ativo, ordem=ordem))
            elif nome in {"Design simples", "Design com henna", "Cílios tufinho", "Remoção"}:
                # Mantém os valores oficiais atualizados sem sobrescrever outros serviços.
                existe.descricao = descricao
                existe.preco = preco
                existe.categoria = categoria
                existe.ativo = True
                existe.ordem = ordem

        config = db.query(ConfiguracaoBarbearia).first()
        if config and config.nome_barbearia in {"Barbearia Style", "Ateliê de Beleza"}:
            config.nome_barbearia = "Estúdio Souza"
        if config and not config.whatsapp_numero:
            config.whatsapp_numero = "5585991858293"
        if config and not config.telefone_contato:
            config.telefone_contato = "(85) 99185-8293"
        db.commit()
    finally:
        db.close()

    # Iniciar serviço de notificações
    notificacao_service.start()

    logger.info("Aplicação iniciada com sucesso!")
    yield

    # Shutdown
    logger.info("Encerrando aplicação...")
    notificacao_service.stop()


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Sistema de gestão para estúdio de beleza",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")

# Rotas de páginas (frontend) - DEVEM vir ANTES dos routers para ter prioridade
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="public/index.html", context={"request": request})


@app.get("/agendar", response_class=HTMLResponse)
async def pagina_agendar(request: Request):
    return templates.TemplateResponse(request=request, name="public/agendar.html", context={"request": request})


@app.get("/meus-agendamentos", response_class=HTMLResponse)
async def pagina_meus_agendamentos(request: Request):
    return templates.TemplateResponse(request=request, name="public/meus_agendamentos.html", context={"request": request})


@app.get("/admin", response_class=HTMLResponse)
async def admin_login(request: Request):
    return templates.TemplateResponse(request=request, name="admin/login.html", context={"request": request})


@app.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard(request: Request):
    return templates.TemplateResponse(request=request, name="admin/dashboard.html", context={"request": request})


@app.get("/admin/clientes", response_class=HTMLResponse)
async def admin_clientes(request: Request):
    return templates.TemplateResponse(request=request, name="admin/clientes.html", context={"request": request})


@app.get("/admin/agendamentos", response_class=HTMLResponse)
async def admin_agendamentos(request: Request):
    return templates.TemplateResponse(request=request, name="admin/agendamentos.html", context={"request": request})


@app.get("/admin/servicos", response_class=HTMLResponse)
async def admin_servicos(request: Request):
    return templates.TemplateResponse(request=request, name="admin/servicos.html", context={"request": request})


@app.get("/admin/fidelidade", response_class=HTMLResponse)
async def admin_fidelidade(request: Request):
    return templates.TemplateResponse(request=request, name="admin/fidelidade.html", context={"request": request})


@app.get("/fidelidade", response_class=HTMLResponse)
async def pagina_fidelidade_publica(request: Request):
    return templates.TemplateResponse(request=request, name="public/fidelidade.html", context={"request": request})


@app.get("/admin/relatorios", response_class=HTMLResponse)
async def admin_relatorios(request: Request):
    return templates.TemplateResponse(request=request, name="admin/relatorios.html", context={"request": request})


@app.get("/admin/configuracoes", response_class=HTMLResponse)
async def admin_configuracoes(request: Request):
    return templates.TemplateResponse(request=request, name="admin/configuracoes.html", context={"request": request})


@app.get("/health")
async def health_check():
    return {"status": "ok", "version": settings.APP_VERSION}

# Incluir routers (DEPOIS das rotas HTML para não conflitar)
app.include_router(auth.router)
app.include_router(clientes.router)
app.include_router(servicos.router)
app.include_router(agendamentos.router)
app.include_router(fidelidade.router)
app.include_router(configuracao.router)
app.include_router(admin.router)
app.include_router(publico.router)
app.include_router(produtos.router)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=settings.DEBUG)