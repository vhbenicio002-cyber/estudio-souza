"""Temporary, admin-authenticated SQLite export for the PostgreSQL migration."""
from io import BytesIO
from pathlib import Path
import sqlite3
import tempfile
import zipfile

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from app.database import engine
from app.routes.auth import get_current_admin
from app.models.user import User

router = APIRouter(prefix="/admin/migracao", tags=["Migração temporária"])


@router.get("/exportar-sqlite")
def exportar_sqlite(current_user: User = Depends(get_current_admin)):
    # This endpoint deliberately refuses to export any non-SQLite database.
    if engine.dialect.name != "sqlite":
        raise HTTPException(status_code=409, detail="O banco ativo não é SQLite.")

    db_path = engine.url.database
    if not db_path or db_path == ":memory:":
        raise HTTPException(status_code=404, detail="Banco SQLite em arquivo não encontrado.")
    source_path = Path(db_path)
    if not source_path.is_absolute():
        source_path = source_path.resolve()
    if not source_path.is_file():
        raise HTTPException(status_code=404, detail="Arquivo do banco SQLite não encontrado nesta instância.")

    # SQLite backup API produces a consistent snapshot and includes committed WAL data.
    with tempfile.TemporaryDirectory(prefix="estudio-souza-export-") as tmp:
        snapshot_path = Path(tmp) / "estudio_souza.sqlite3"
        try:
            with sqlite3.connect(str(source_path), timeout=15) as source:
                with sqlite3.connect(str(snapshot_path)) as destination:
                    source.backup(destination)
            archive = BytesIO()
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.write(snapshot_path, arcname="estudio_souza.sqlite3")
                zf.writestr(
                    "LEIA-ME.txt",
                    "Exportação consistente do banco SQLite do Estúdio Souza.\n"
                    "Contém dados pessoais e deve ser mantida em local privado.\n"
                    "Não compartilhe publicamente.\n",
                )
            archive.seek(0)
        except sqlite3.Error:
            raise HTTPException(status_code=500, detail="Não foi possível gerar a cópia consistente do banco.")

    headers = {"Content-Disposition": 'attachment; filename="estudio-souza-backup-migracao.zip"',
               "Cache-Control": "no-store, private"}
    return StreamingResponse(archive, media_type="application/zip", headers=headers)
