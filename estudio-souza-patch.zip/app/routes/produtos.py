from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from decimal import Decimal
from typing import Optional
from app.database import get_db
from app.models.produto import Produto
from app.models.cliente import Cliente
from app.services.fidelidade import FidelidadeService
from app.routes.auth import get_current_admin

router = APIRouter(prefix="/produtos", tags=["Produtos"])

@router.get("/")
def listar_produtos(db: Session = Depends(get_db), current_user=Depends(get_current_admin)):
    return db.query(Produto).order_by(Produto.nome).all()

@router.post("/", status_code=201)
def criar_produto(nome: str = Body(...), descricao: Optional[str] = Body(None), preco: float = Body(0), pontos_por_compra: int = Body(0), db: Session = Depends(get_db), current_user=Depends(get_current_admin)):
    if not nome.strip() or preco < 0 or pontos_por_compra < 0:
        raise HTTPException(400, "Informe nome, preço e pontuação válidos")
    produto = Produto(nome=nome.strip(), descricao=descricao, preco=Decimal(str(preco)), pontos_por_compra=pontos_por_compra)
    db.add(produto); db.commit(); db.refresh(produto)
    return produto

@router.put("/{produto_id}")
def atualizar_produto(produto_id: int, nome: Optional[str] = Body(None), descricao: Optional[str] = Body(None), preco: Optional[float] = Body(None), pontos_por_compra: Optional[int] = Body(None), ativo: Optional[bool] = Body(None), db: Session = Depends(get_db), current_user=Depends(get_current_admin)):
    p = db.query(Produto).filter(Produto.id == produto_id).first()
    if not p: raise HTTPException(404, "Produto não encontrado")
    if nome is not None and not nome.strip():
        raise HTTPException(400, "O nome do produto é obrigatório")
    if preco is not None:
        if preco < 0: raise HTTPException(400, "Preço não pode ser negativo")
        p.preco = Decimal(str(preco))
    if pontos_por_compra is not None:
        if pontos_por_compra < 0: raise HTTPException(400, "Pontos não podem ser negativos")
        p.pontos_por_compra = pontos_por_compra
    if nome is not None: p.nome = nome.strip()
    if descricao is not None: p.descricao = descricao
    if ativo is not None: p.ativo = ativo
    db.commit(); db.refresh(p); return p

@router.post("/{produto_id}/registrar-compra")
def registrar_compra(produto_id: int, cliente_id: int = Body(...), quantidade: int = Body(1), db: Session = Depends(get_db), current_user=Depends(get_current_admin)):
    p = db.query(Produto).filter(Produto.id == produto_id, Produto.ativo == True).first()
    c = db.query(Cliente).filter(Cliente.id == cliente_id, Cliente.ativo == True).first()
    if not p: raise HTTPException(404, "Produto não encontrado ou inativo")
    if not c: raise HTTPException(404, "Cliente não encontrado")
    if quantidade < 1 or quantidade > 100: raise HTTPException(400, "Quantidade deve ser entre 1 e 100")
    pontos = p.pontos_por_compra * quantidade
    if pontos <= 0: raise HTTPException(400, "Este produto não gera pontos")
    f = FidelidadeService(db).adicionar_pontos(c.id, pontos, f"Compra: {p.nome} (x{quantidade})")
    return {"message":"Compra registrada", "pontos_adicionados":pontos, "pontos_atual":f.pontos_atual}
