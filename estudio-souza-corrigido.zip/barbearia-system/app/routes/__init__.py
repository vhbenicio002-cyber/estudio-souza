from app.routes import auth, clientes, servicos, agendamentos, fidelidade, configuracao, admin, publico

__all__ = ["auth", "clientes", "servicos", "agendamentos", "fidelidade", "configuracao", "admin", "publico"]