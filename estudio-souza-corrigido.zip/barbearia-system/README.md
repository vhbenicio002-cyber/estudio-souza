# Estúdio Souza — sistema de gestão

Sistema de agendamento e gestão para um espaço de beleza com uma única profissional. O fluxo de marcação usa uma agenda única: serviço, data, horário e dados da cliente.

## Serviços previstos
- Design de cílios
- Design de sobrancelhas
- Manicure
- Pedicure

O catálogo inicial é criado com os serviços acima **inativos e sem preço**. Entre no painel administrativo, ajuste preço, duração e descrição de cada serviço e ative apenas os que serão oferecidos. Assim o site não publica valores inventados.

## Requisitos
- Python 3.10 a 3.13
- pip

## Instalação local
1. Crie e ative um ambiente virtual.
2. Instale as dependências: `pip install -r requirements.txt`.
3. Copie `.env.example` para `.env`. Defina `DEBUG=true` apenas em ambiente local.
4. Para uso fora de testes, configure uma `SECRET_KEY` aleatória com pelo menos 32 caracteres e uma `ADMIN_PASSWORD` forte com pelo menos 12 caracteres. O servidor não inicia em modo de produção com credenciais de exemplo.
5. Inicie com `python run.py`.
6. Acesse `http://localhost:8000`.

O banco SQLite é criado automaticamente na primeira execução. O arquivo de banco local não deve ser publicado junto ao código; use um banco persistente no ambiente de hospedagem. O agendador de lembretes depende do APScheduler, incluído nas dependências.

## Alterações desta adaptação
- Identidade visual em tons rosé, nude e ameixa.
- Textos e páginas adaptados para um ateliê de beleza.
- Agenda única, sem seleção ou divisão por barbeiros/profissionais.
- Conflitos de horário verificados globalmente para impedir atendimentos simultâneos.
- Painel e relatórios focados em clientes, serviços, agenda e faturamento.
- Catálogo inicial de beleza criado sem preços presumidos.
- Estrutura antiga do banco mantida compatível para preservar histórico de agendamentos.
